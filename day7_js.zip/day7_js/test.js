
let className="javascript";
 alert(className);
 